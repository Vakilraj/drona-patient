import React, { useState } from 'react';
import {
    SafeAreaView,
    ScrollView,
    View,
    Text, TextInput, TouchableOpacity, FlatList, Image, BackHandler, Platform
} from 'react-native';
import styles from './style';

import * as signupActions from '../../redux/actions/signupActions';
import * as apiActions from '../../redux/actions/apiActions';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import _ from 'lodash';
import arrowBack from '../../../assets/back_blue.png';
import tickIcon from '../../../assets/tick.png';
import langIcon from '../../../assets/lang.png';
import downKey from '../../../assets/downKey.png';

import eCardsIcon from '../../../assets/ecards.png';
import cameraIcon from '../../../assets/cam.png';
import blueTickIcon from '../../../assets/selected_violet.png';
import crossIcon from '../../../assets/cross.png';


import Color from '../../components/Colors';
import CustomFont from '../../components/CustomFont';
import { responsiveWidth, responsiveHeight, responsiveFontSize } from 'react-native-responsive-dimensions';
import AsyncStorage from '@react-native-community/async-storage';
import { Card } from 'native-base';
import ImagePicker from 'react-native-image-picker';
import Modal from 'react-native-modal';
import Snackbar from 'react-native-snackbar';
let base64 = '', filename = '';
let selectedLanguageGuid = '';
let cardLanguageGuid = '';
let staticImageUrl = '';
class EditCard extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            isModalVisible: false,
            selectedLanguageNumber: 0,
            dName: '',
            cardImage: '',
            dCode: 'dro.na/KritiK',
            imageSource: '',
            languageArr: [],
            curentLanguage: 'English',

        };
    }
    componentDidMount() {
        cardLanguageGuid = this.props.navigation.state.params.cardGuid;
        let { actions, signupDetails } = this.props;
        this.setState({ dName: 'Dr. ' + signupDetails.fname + ' ' + signupDetails.lname });
        this.setState({ imageSource: { uri: signupDetails.profileImgUrl } });


        let params = {
            "UserGuid": signupDetails.UserGuid,
            "ClinicGuid": null,
            "DoctorGuid": signupDetails.UserGuid,
            "Version": null,
            "Data": {
                "CardLanguageGuid": cardLanguageGuid
            }
        }
        actions.callLogin('FuncForDrAppToGetEcardDetails', 'post', params, signupDetails.accessToken, 'ecarddetails');
        this.backHandler = BackHandler.addEventListener('hardwareBackPress', () => this.props.navigation.goBack())
    }

    async UNSAFE_componentWillReceiveProps(newProps) {
        if (newProps.responseData && newProps.responseData.tag) {
            let tagname = newProps.responseData.tag;
            let data = newProps.responseData.data;
            if (tagname === 'ecarddetails') {
                if (newProps.responseData.statusCode === '0') {
                    // alert(JSON.stringify(data))
                    if (data != null) {
                        this.setState({ cardImage: data.fullImageUrl });
                        // this.setState({dName : data.doctorName})
                        this.setState({ languageArr: data.languageList ?data.languageList :[] });
                        selectedLanguageGuid = data.languageList[0].languageGuid;

                        staticImageUrl = data.fullImageUrl;
                    }
                }

            } else if (tagname === 'saveecard') {
                if (newProps.responseData.statusCode === '0') {
                    let data = newProps.responseData.data;
                    // this.props.navigation.navigate('PreviewCard', {res : data});
                    // this.props.navigation.navigate('PreviewCard', {res : staticImageUrl});
                    console.log('Output ' + JSON.stringify(data))
                }

            }
        }
    }

    selectImagePress = () => {
        var options = {
            title: 'Select Profile Picture',
            storageOptions: {
                skipBackup: true,
                path: 'images',
            },
        };
        ImagePicker.showImagePicker(options, response => {
            if (response.didCancel) {
                console.log('User cancelled image picker');
            } else if (response.error) {
                console.log('ImagePicker Error: ', response.error);
            } else if (response.customButton) {
                console.log('User tapped custom button: ', response.customButton);
            } else {
                base64 = '';
                const source = { uri: response.uri };
                base64 = response.data;
                filename = response.fileName;
                //fileType = response.type;
                //imagArr.push(source)
                this.setState({ imageSource: source });
            }
        });
    }
    typeDName = (text) => {
        this.setState({ dName: text })
    }
    changeLanguageClk = () => {
        this.setState({ isModalVisible: true })
    }
    selectLanguage = (item, index) => {
        selectedLanguageGuid = item.languageGuid;
        this.setState({ selectedLanguageNumber: index, curentLanguage: item.languageName })
        // this.changeLanguageAPICall()
    }
    callLanguageAPI = () => {
        if (selectedLanguageGuid) {
            this.setState({
                isModalVisible: false,
            })
            selectedLanguageGuid = ''
            this.changeLanguageAPICall()
        } else {
            Snackbar.show({ text: 'Please select language', duration: Snackbar.LENGTH_SHORT, backgroundColor: Color.primary });

        }

    }
    changeLanguageAPICall = () => {
        let { actions, signupDetails } = this.props;
        let params = {
            "UserGuid": signupDetails.UserGuid,
            "ClinicGuid": null,
            "DoctorGuid": signupDetails.UserGuid,
            "Version": null,
            "Data": {
                "CardLanguageGuid": cardLanguageGuid,
                "LanguageGuid": selectedLanguageGuid,
            }
        }
        actions.callLogin('FuncForDrAppToGetEcardDetails', 'post', params, signupDetails.accessToken, 'ecarddetails');


    }

    renderList = (item, index) => {
        return (

            <TouchableOpacity style={[styles.lRowView, {
                borderWidth: 1, borderColor: this.state.selectedLanguageNumber === index ? Color.liveBg : Color.borderColor,
                backgroundColor: this.state.selectedLanguageNumber === index ? Color.genderSelection : Color.white
            }]} onPress={() => this.selectLanguage(item, index)}>
                {/* <Image style={{ height: responsiveWidth(4), width: responsiveWidth(3) }} source={this.state.selectedLanguageNumber === index ? blueTickIcon : tickIcon} />
                */}
                <Text style={[styles.languageName, { fontSize: this.state.selectedLanguageNumber === index ? CustomFont.font14 : CustomFont.font16 }]}>{item.languageName}</Text>
            </TouchableOpacity>

        )
    }
    closeLanguagePopup = () => {
        this.setState({ isModalVisible: false })
    }
    saveECard = () => {

        if (this.state.dName == '') {
            Snackbar.show({ text: 'Please Enter Your Name', duration: Snackbar.LENGTH_SHORT, backgroundColor: Color.primary });
        }
        else if (this.state.imageSource == '') {
            Snackbar.show({ text: 'Please Select Your Image', duration: Snackbar.LENGTH_SHORT, backgroundColor: Color.primary });
        }
        else {
            let tempObj = {};
            tempObj.dName = this.state.dName;
            tempObj.cardImage = staticImageUrl;
            tempObj.doctorImage = this.state.imageSource;

            this.props.navigation.navigate('PreviewCard', { res: tempObj });
            //     let { actions, signupDetails } = this.props;
            // let tempObj = {};
            // if(base64 != ''){
            //     tempObj.AttachmentGuid = null;
            //     tempObj.OrgFileExt = '.png';
            //     tempObj.OrgFileName = 'testimg';
            //     tempObj.SysFileName = null;
            //     tempObj.SysFileExt = null;
            //     tempObj.FileBytes = base64; 
            // }
            // let params = {
            //     "UserGuid":signupDetails.UserGuid,
            //     "ClinicGuid":null,
            //     "DoctorGuid":signupDetails.UserGuid,
            //     "Version":null,
            //     "Data":{
            //         "CardLanguageGuid":cardLanguageGuid,
            //         "FullImageUrl": this.state.cardImage,
            //         "DoctorName": this.state.dName,
            //         "Attachment": tempObj,
            //         "LanguageGuid": selectedLanguageGuid ,
            //         "EcardCode":null,
            //         "Doctorcode":null,
            //         "LanguageList":null
            //       }
            //     }
            //     console.log('request Params:Anup1 ' + JSON.stringify(params));
            //     actions.callLogin('FuncForDrAppToSaveEcardDetails', 'post', params, signupDetails.accessToken, 'saveecard');
        }


    }

    render() {
        let modalHeight = this.state.languageArr.length <= 3 ? 35 : 62
        let bottomHeight = this.state.languageArr.length <= 3 ? -65 : -40
       
       
        return (
            <SafeAreaView style={{ flex: 1, backgroundColor: Color.patientBackground }}>
                <View style={{ paddingLeft: responsiveWidth(4), paddingRight: responsiveWidth(4), height: Platform.OS == 'ios' ? 40 : responsiveHeight(7.5), flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-start', backgroundColor: Color.white, width: '100%' }}>
                    {/* <View style={{ flexDirection: 'row', flex: 5 }}>
                        <TouchableOpacity style={{ paddingRight: 15, flexDirection: 'row', alignItems: 'center' }} onPress={() => this.props.navigation.goBack()}>
                            <Image source={arrowBack} style={{ height: responsiveWidth(4.5), width: responsiveWidth(5) }} />
                        </TouchableOpacity>
                        <Text style={styles.headerTxt}>Edit e-Card</Text>
                    </View> */}

                    <View style={{ flexDirection: 'row', flex: 5 }}>
                        <TouchableOpacity onPress={() => this.props.navigation.goBack()} >
                            <Image source={arrowBack} style={{ width: responsiveFontSize(3.2), height: responsiveFontSize(3.2), padding: responsiveHeight(1), resizeMode: 'contain' }} />
                        </TouchableOpacity>
                        <Text style={{ fontFamily: CustomFont.fontName, color: Color.fontColor, fontSize: CustomFont.font16, fontWeight: CustomFont.fontWeight700, marginLeft: responsiveWidth(4) }}>Edit Card</Text>
                    </View>

                    {/* <View style = {{backgroundColor : 'red', flexDirection : 'row', flex  :3, justifyContent: 'flex-end'}}> 
                          
                        </View> */}
                    <TouchableOpacity style={{ flexDirection: 'row', flex: 1, justifyContent: 'space-between', alignItems: 'center' }} onPress={this.changeLanguageClk}>
                        {/* <TouchableOpacity style={{ flexDirection: 'row', alignItems: 'center' }} onPress={this.changeLanguageClk}>
                            <Image source={langIcon} style={{ height: responsiveWidth(6), width: responsiveWidth(5) }} />
                        </TouchableOpacity>
                        <TouchableOpacity style={{ flexDirection: 'row', alignItems: 'center' }} onPress={this.saveECard}>
                            <Image source={tickIcon} style={{tintColor:Color.primary, height: responsiveWidth(6), width: responsiveWidth(5) }} />
                        </TouchableOpacity> */}
                        <Text style={{ color: Color.optiontext, fontSize: CustomFont.font14, fontWeight: CustomFont.fontWeight400, fontFamily: CustomFont.fontName, paddingLeft: responsiveHeight(-1), paddingRight: responsiveHeight(1) }}>{this.state.curentLanguage}</Text>
                        <Image source={downKey} style={{ tintColor: Color.primary, height: responsiveWidth(3), width: responsiveWidth(3), resizeMode: 'contain', }} />

                    </TouchableOpacity>
                </View>
                <View style={{ flex: 1, margin: responsiveHeight(2), backgroundColor: Color.white, borderRadius: 10, marginBottom: responsiveHeight(12) }}>
                <ScrollView>
                    <View style={{ flexDirection: 'row', paddingTop: 20, paddingBottom: 20, width: '100%' }}>
                        <View style={{ flex: 1, marginLeft: responsiveWidth(3), justifyContent: 'center', alignItems: 'flex-start' }}>
                            {
                                this.state.imageSource == '' ?
                                    <TouchableOpacity onPress={this.selectImagePress} >
                                        <Image source={cameraIcon} style={styles.imageContainer} />
                                    </TouchableOpacity> :
                                    <View style={{ alignItems: 'center' }}>
                                        <TouchableOpacity onPress={this.selectImagePress} style={styles.imageContainer}>
                                            <Image source={this.state.imageSource} style={{ height: '100%', width: '100%', borderRadius: 50 }} />
                                        </TouchableOpacity>
                                        {/* <Text onPress={this.selectImagePress} style={{ color: Color.primary, fontSize: CustomFont.font16 }}>Edit</Text>
                                     */}
                                    </View>
                            }

                        </View>
                        <View style={{ flex: 3.5, justifyContent: 'center', marginRight: responsiveWidth(3),marginLeft: responsiveWidth(4) }}>
                            <Text style={{
                                color: Color.optiontext,
                                fontFamily: CustomFont.fontName, fontSize: CustomFont.font12, fontWeight: CustomFont.fontWeight500
                            }}>Doctor's Name</Text>
                            <TextInput value={this.state.dName} style={styles.doctorNameInput}
                                onChangeText={this.typeDName}>
                            </TextInput>
                        </View>
                    </View>
                    <View style={styles.card}>
                        <View>
                            <Image style={{width: '100%', height: Platform.OS=='android'? responsiveHeight(70):responsiveHeight(55), borderRadius: 10,resizeMode:'contain' }} source={{ uri: this.state.cardImage }} />
                        </View>
                        {/* <View style={{ flex: 1, paddingLeft: 30, }}>
                            <Text style={{
                                marginTop: 10, color: Color.fontColor, fontFamily: CustomFont.fontName,
                                fontSize: CustomFont.font16
                            }}>
                                {this.state.dName}
                            </Text>
                            <Text style={{ color: Color.primary, fontFamily: CustomFont.fontName, fontSize: CustomFont.font14 }}>
                                {this.state.dCode}
                            </Text>
                        </View> */}
                    </View>

                    </ScrollView>
                </View>
            
                <View style={{ position: 'absolute', bottom: 0, width: '100%', flex: 1, alignItems: 'center', justifyContent: 'center', borderRadius: 4, height: responsiveHeight(10), backgroundColor: Color.white, borderTopLeftRadius: 20, borderTopRightRadius: 20 }}>

                    <TouchableOpacity style={{ alignItems: 'center', marginBottom: responsiveHeight(2.5), justifyContent: 'center', borderRadius: 5, height: responsiveHeight(6), width: responsiveWidth(93), backgroundColor: '#5715D2', marginTop: 30 }}
                        onPress={this.saveECard}>
                        <Text style={{ fontFamily: CustomFont.fontName, color: Color.white, fontSize: CustomFont.font14, textAlign: 'center', fontWeight: CustomFont.fontWeight600 }}>Next</Text>
                    </TouchableOpacity>
                </View>

                <Modal isVisible={this.state.isModalVisible} >
                    <View style={{ height: responsiveHeight(modalHeight), marginBottom: responsiveHeight(bottomHeight), ...styles.languageModalMainView, }}>
                        <View style={{ width: '100%', flexDirection: 'row', marginTop: 15, marginLeft: 10, }}>
                            <View style={{ flexDirection: 'row', flex: 1, alignItems: 'center' }}>
                                {/* <Image source={langIcon} style={{ height: responsiveWidth(4), width: responsiveWidth(3) }} /> */}
                                <Text style={{ marginLeft: 10, fontFamily: CustomFont.fontName, fontSize: CustomFont.font16, fontWeight: CustomFont.fontWeight700, color: Color.fontColor }}>Select Language</Text>
                            </View>

                            <View style={{ flexDirection: 'row', paddingRight: 25, flex: 1, justifyContent: 'flex-end' }}>
                                <TouchableOpacity onPress={this.closeLanguagePopup}>
                                    <Image source={crossIcon} style={{ height: responsiveWidth(5), width: responsiveWidth(5) }} />
                                </TouchableOpacity>
                            </View>
                        </View>
                        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', marginBottom: responsiveHeight(8) }}>
                            <FlatList

                               //data={[{ "languageGuid": "25078687-c277-11eb-b68b-0022486b91c8", "languageName": "English" }, { "languageGuid": "4ccb5683-c277-11eb-b68b-0022486b91c8", "languageName": "Hindi" }, { "languageGuid": "601adc99-c277-11eb-b68b-0022486b91c8", "languageName": "Marathi" }, { "languageGuid": "601adc99-c277-11eb-b68b-0022486b91c8", "languageName": "Marathi" }, { "languageGuid": "601adc99-c277-11eb-b68b-0022486b91c8", "languageName": "Marathi" }, { "languageGuid": "601adc99-c277-11eb-b68b-0022486b91c8", "languageName": "Marathi" }, { "languageGuid": "601adc99-c277-11eb-b68b-0022486b91c8", "languageName": "Marathi" }, { "languageGuid": "601adc99-c277-11eb-b68b-0022486b91c8", "languageName": "Marathi" }, { "languageGuid": "601adc99-c277-11eb-b68b-0022486b91c8", "languageName": "Marathi" }, { "languageGuid": "601adc99-c277-11eb-b68b-0022486b91c8", "languageName": "Marathi" }, { "languageGuid": "601adc99-c277-11eb-b68b-0022486b91c8", "languageName": "Marathi" }, { "languageGuid": "601adc99-c277-11eb-b68b-0022486b91c8", "languageName": "Marathi" }, { "languageGuid": "601adc99-c277-11eb-b68b-0022486b91c8", "languageName": "Marathi" }, { "languageGuid": "601adc99-c277-11eb-b68b-0022486b91c8", "languageName": "Marathi" }]}
                                data={this.state.languageArr}
                                style={{ margin: 12 }}
                                numColumns={3}
                                showsVerticalScrollIndicator={false}
                                renderItem={({ item, index }) => this.renderList(item, index)}
                                extraData={this.state}
                                keyExtractor={(item, index) => index.toString()}
                            //onEndReached={this.loadMoreData}
                            />
                        </View>

                        <View style={{ position: 'absolute', bottom: 10, width: '100%', flex: 1, alignItems: 'center', justifyContent: 'center', borderRadius: 4, height: responsiveHeight(6), marginBottom: responsiveHeight(2), backgroundColor: Color.white, borderTopLeftRadius: 20, borderTopRightRadius: 20 }}>

                            <TouchableOpacity style={{ alignItems: 'center', justifyContent: 'center', borderRadius: 5, height: responsiveHeight(6), width: responsiveWidth(90), backgroundColor: '#5715D2', }}
                                onPress={this.callLanguageAPI}>
                                <Text style={{ fontFamily: CustomFont.fontName, color: Color.white, fontSize: CustomFont.font14, textAlign: 'center', fontWeight: CustomFont.fontWeight600 }}>Done</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                </Modal>

            </SafeAreaView>
        );
    }
}

const mapStateToProps = state => ({
    signupDetails: state.signupReducerConfig.signupDetails,
    responseData: state.apiResponseDataConfig.responseData,
    loading: state.apiResponseDataConfig.loading,
});

const ActionCreators = Object.assign(
    {},
    apiActions, signupActions
);
const mapDispatchToProps = dispatch => ({
    actions: bindActionCreators(ActionCreators, dispatch),
});

export default connect(
    mapStateToProps,
    mapDispatchToProps,
)(EditCard);
