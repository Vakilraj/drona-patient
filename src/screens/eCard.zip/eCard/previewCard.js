import React, { useState } from 'react';
import {
  SafeAreaView,
  View,
  Text, TouchableOpacity,
  Image,
  Platform,
  PermissionsAndroid,
  BackHandler, Button
} from 'react-native';
import styles from './style';
import Modal from 'react-native-modal';
import * as signupActions from '../../redux/actions/signupActions';
import * as apiActions from '../../redux/actions/apiActions';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import _ from 'lodash';
import arrowBack from '../../../assets/back_blue.png';
import dImage from '../../../assets/dImage.png';
import eCardsIcon from '../../../assets/ecards.png';
import playStoreIcon from '../../../assets/appplaystore.png';
//import playStoreIcon from '../../../assets/language_dropdown.png';

import TickIcon from '../../../assets/green_tick.png';
import shareIcon from '../../../assets/sharepreview.png';
import downloadIcon from '../../../assets/downloadpreview.png';

import Color from '../../components/Colors';
import CustomFont from '../../components/CustomFont';
import { responsiveWidth, responsiveHeight, responsiveFontSize } from 'react-native-responsive-dimensions';
import AsyncStorage from '@react-native-community/async-storage';
import { Card } from 'native-base';
import ImagePicker from 'react-native-image-picker';
import Share from 'react-native-share';
import RNFetchBlob from 'rn-fetch-blob';
import RNFS from 'react-native-fs';
import ViewShot from 'react-native-view-shot';
class PreviewCard extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      isModalVisible: false,
      cityArr: [],
      clinicViewShowStatus: true,
      listShowStatusCity: false,
      listShowStatusClinic: false,
      clinicArray: [],
      clinicName: '',
      btnText: 'Next',
      selectedCards: 0,
      activeSlide: 0,
      dName: '',
      dCode: '',
      imageSource: '',
      previewCardUrl: '',
      doctorName: '',
      downLoadBtnBcColor: '#FFFFFF',
      isdownloadClicked: false,
      doctorImageUrl: '',
      successPdfDownload: false,
    };
  }
  componentDidMount() {
    let { actions, signupDetails } = this.props;
    this.setState({ dCode: signupDetails.shareLinkUrl});
    
    this.setState({ previewCardUrl: this.props.navigation.state.params.res.cardImage });
    this.setState({ doctorName: this.props.navigation.state.params.res.dName });
    this.setState({ doctorImageUrl: this.props.navigation.state.params.res.doctorImage });
    this.backHandler = BackHandler.addEventListener('hardwareBackPress', () => this.props.navigation.goBack())
  //  console.log('share dcode' + this.state.dCode);
  //alert(this.props.navigation.state.params.res.dName)
  }


  captureAndShareScreenshot = () => {
    let { actions, signupDetails } = this.props;
    this.refs.viewShot.capture().then((uri) => {
      RNFS.readFile(uri, 'base64').then((res) => {
        let urlString = 'data:image/jpeg;base64,' + res;
        let options = {
          title: 'Share Title',
          message: 'Hello! For teleconsultation with ' +
            this.state.doctorName +'  at his virtual clinic, '+signupDetails.clinicName + ' Click to below link \n\n'+this.state.dCode,
          url: urlString,
          type: 'image/jpeg',
        };
        Share.open(options)
          .then((res) => {
            console.log('YES ' + JSON.stringify(res));
          })
          .catch((err) => {
            err && console.log(err);
          });
      });
    });
  }; 
  downloadsScreenshot = () => {
    let { actions, signupDetails } = this.props;
    this.refs.viewShot.capture().then((uri) => {
      RNFS.readFile(uri, 'base64').then((res) => {
        let urlString = 'data:image/jpeg;base64,' + res;
        let options = {
          title: 'Share Title',
          message: 'Hello! For teleconsultation with ' +
            this.state.doctorName +'  at his virtual clinic, '+signupDetails.clinicName + ' Click to below link \n\n'+this.state.dCode,
          url: urlString,
          type: 'image/jpeg',
          saveToFiles:true
        };
        Share.open(options)
          .then((res) => {
            console.log('YES ' + JSON.stringify(res));
          })
          .catch((err) => {
            err && console.log(err);
          });
      });
    });
  };




  getExtention = filename => {
    return /[.]/.exec(filename) ?
      /[^.]+$/.exec(filename) : undefined;
  }

  pressDownLoad = async () => {
    this.setState({ isdownloadClicked: true })
    // if (Platform.OS === 'ios') {
    //     this.downloadImage()
    //   }
    //   else {
    //     try {
    //       const granted = await PermissionsAndroid.request(
    //         PermissionsAndroid.PERMISSIONS.WRITE_EXTERNAL_STORAGE,
    //         {
    //           title: 'Storage Permission Required',
    //           message:
    //             'App needs access to your storage to download Photos',
    //         }
    //       );
    //       if (granted === PermissionsAndroid.RESULTS.GRANTED) {
    //         // Once user grant the permission start downloading
    //         console.log('Storage Permission Granted.');
    //         this.downloadImage();
    //       } else {
    //         // If permission denied then show alert
    //         alert('Storage Permission Not Granted');
    //       }
    //     } catch (err) {
    //       console.warn(err);
    //       console.log('Error:: ' + err);
    //     }
    //   }
    this.refs.viewShot.capture().then((uri) => {
      //if(Platform.OS=='android'){
        RNFS.readFile(uri, 'base64').then((res) => {
          var text = "";
          var ramdomstr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
          for (var i = 0; i < 5; i++)
            text += ramdomstr.charAt(Math.floor(Math.random() * ramdomstr.length));
          let imgName = text + '.png'
          const dirs = RNFetchBlob.fs.dirs;
          // var path = dirs.DCIMDir + "/image.png";
          //var path = dirs.DCIMDir + imgName;
          var path = dirs.DocumentDir + imgName;
          if(Platform.OS=='android'){
            RNFetchBlob.fs.writeFile(path, res, 'base64')
            .then((res) => {
              this.setState({ isdownloadClicked: false })
              // alert('Image Downloaded Successfully.');
              this.setState({ successPdfDownload: true })
  
            });
          }else{
            RNFetchBlob.ios.previewDocument(res);
          }
  
        });
//       }else{
//         var d = new Date();
// var fileName = d.getTime()+'.jpg';
// let destPath= RNFetchBlob.fs.dirs.DownloadDir + '/' + fileName;
// // console.log(destPath)
// // alert(destPath)
//         RNFS.moveFile(uri, destPath).then((res) => {
//           this.setState({ successPdfDownload: true })
//         });
//       }
      
    });
  }
  render() {
    let { actions, signupDetails } = this.props;
    // alert(signupDetails.shareLinkUrl)
    console.log("signupDetails.shareLinkUrl", signupDetails.shareLinkUrl);
    //alert(this.props.navigation.state.params.selectedState);
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: Color.patientBackground }}>
        <View style={{ paddingLeft: responsiveWidth(4), paddingRight: responsiveWidth(4), height: Platform.OS == 'ios' ? 40 : responsiveHeight(7.5), flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-start', backgroundColor: Color.white, width: '100%' }}>
          {/* <View style={{ flexDirection: 'row', flex: 1 }}>
            <TouchableOpacity style={{ paddingRight: 15, flexDirection: 'row', alignItems: 'center' }} onPress={() => this.props.navigation.goBack()}>
              <Image source={arrowBack} style={{ height: responsiveWidth(4.5), width: responsiveWidth(5) }} />
            </TouchableOpacity>
            <Text style={styles.headerTxt}>Preview eCard</Text>
          </View> */}
          <View style={{ flexDirection: 'row', flex: 1 }}>
            <TouchableOpacity onPress={() => this.props.navigation.goBack()} >
              <Image source={arrowBack} style={{ width: responsiveFontSize(3.2), height: responsiveFontSize(3.2), padding: responsiveHeight(1), resizeMode: 'contain' }} />
            </TouchableOpacity>
            <Text style={{ fontFamily: CustomFont.fontName, color: Color.fontColor, fontSize: CustomFont.font16, fontWeight: CustomFont.fontWeight700, marginLeft: responsiveWidth(4) }}>Preview Card</Text>
          </View>
        </View>
        <View style={{ flex: 1, margin: responsiveWidth(0), }}>
          <View style={styles.cardpreview}>
            <ViewShot
              style={styles.viewshot}
              ref="viewShot"
              options={{ format: 'jpg', quality: 0.9 }}>
              <View style={{ flex: 5 }}>
                {/* <Image style={{ width: '100%', height: '100%', borderRadius: 10 }} source={{ uri: this.state.previewCardUrl }} />
                */}
                <Image style={{ width: '100%', height: Platform.OS=='android'? responsiveHeight(65):responsiveHeight(50), borderRadius: 10,resizeMode:'contain',marginTop:10 }} source={{ uri: this.state.previewCardUrl }} />
              </View>
              <View style={{ alignItems: 'center', flex: .6, marginTop: 0, paddingLeft: 30, flexDirection: 'row' }}>
                <View style={{ flex: 1 }}>
                  <Image style={{ height: responsiveWidth(12), width: responsiveWidth(12), borderRadius: responsiveWidth(6) }} source={{ uri: this.state.previewCardUrl}} />
                </View>
                <View style={{ flex: 4 }}>
                  <Text style={{
                    color: Color.fontColor, fontFamily: CustomFont.fontName,
                    fontSize: CustomFont.font16
                  }}>
                    {this.state.doctorName}
                  </Text>
                  {/* <Text style={{ color: Color.fontColor, fontFamily: CustomFont.fontName, fontSize: CustomFont.font14 }}>
                    {signupDetails.shareLinkUrl}
                  </Text> */}
                </View>
              </View>

              {/* <View style = {{alignItems : 'center', flex : .7,  paddingLeft : 30, flexDirection : 'row'}}>
                              <Text style = {{color : Color.fontColor, fontFamily : CustomFont.fontName, 
                                fontSize : CustomFont.font16}}> Consult on Drona App :
                             </Text>
                             <Image style = {{marginLeft : responsiveWidth(10), resizeMode : 'contain', height : responsiveWidth(12), width : responsiveWidth(30)}} source = {playStoreIcon}/>
                        </View> */}
            </ViewShot>
          </View>


          <View style={styles.btnView}>
            {/* <TouchableOpacity onPress={this.pressDownLoad} style={[styles.btn1, { borderColor: this.state.isdownloadClicked ? 'red' : Color.primary }]}>
              <Image style={{ resizeMode: 'contain', height: responsiveWidth(6), width: responsiveWidth(6) }} source={downloadIcon} />
              <Text style={[styles.downloadTxt, { color: this.state.isdownloadClicked ? 'red' : Color.primary }]}>Download</Text>
            </TouchableOpacity>
            

            <TouchableOpacity onPress={this.captureAndShareScreenshot} style={styles.btn2}>
              <Image style={{ resizeMode: 'contain', height: responsiveWidth(6), width: responsiveWidth(6) }} source={shareIcon} />
              <Text style={styles.shareTxt}>Share</Text>
            </TouchableOpacity> */}

          </View>
          <View style={{ width: '100%', flex: 1, alignItems: 'center', justifyContent: 'center', borderRadius: 4, height: responsiveHeight(11), backgroundColor: Color.white, borderTopLeftRadius: 20, borderTopRightRadius: 20, position: 'absolute', bottom: 0, flexDirection: 'row' }}>
            <TouchableOpacity style={{ height: responsiveHeight(6), width: responsiveWidth(44), justifyContent: 'center', alignItems: 'center', backgroundColor: Color.cancelButtonBg, borderRadius: 5, marginRight: 10 }}
              onPress={this.downloadsScreenshot}>
              <Text style={{ color: Color.primaryBlue, fontFamily: CustomFont.fontName, fontSize: CustomFont.font14, fontWeight: CustomFont.fontWeight600, fontFamily: CustomFont.fontName }}>Download</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={this.captureAndShareScreenshot} style={{ height: responsiveHeight(6), width: responsiveWidth(44), justifyContent: 'center', alignItems: 'center', backgroundColor: Color.primary, borderRadius: 5 }}>
              <View style={{ borderRadius: responsiveWidth(2.5) }}>
                <Text style={{ color: Color.white, fontFamily: CustomFont.fontName, fontSize: CustomFont.font14, fontWeight: CustomFont.fontWeight600, fontFamily: CustomFont.fontName }}>Share</Text>
              </View>
            </TouchableOpacity>
          </View>
          <Modal isVisible={this.state.successPdfDownload}>
            <View style={[styles.modelViewMessage2]}>
              <Image source={TickIcon} style={{ height: 65, width: 65, marginTop: 30 }} />
              <Text style={{ marginTop: 20, textAlign: 'center', color: Color.darkText, fontSize: CustomFont.font22, fontFamily: CustomFont.fontName }}>
                Image Downloaded Successfully
              </Text>
              <TouchableOpacity
                onPress={() => {
                  this.setState({ successPdfDownload: false })
                }}
                style={{ borderRadius: 5, justifyContent: 'center', alignItems: 'center', backgroundColor: Color.primary, margin: 20, paddingTop: 8, paddingBottom: 8, paddingStart: 27, paddingEnd: 27 }}>
                <Text style={{ color: Color.white, fontSize: CustomFont.font16, fontFamily: CustomFont.fontName }}>Ok</Text>
              </TouchableOpacity>
            </View>
          </Modal>

        </View>
      </SafeAreaView>
    );
  }
}

const mapStateToProps = state => ({
  signupDetails: state.signupReducerConfig.signupDetails,
  responseData: state.apiResponseDataConfig.responseData,
  loading: state.apiResponseDataConfig.loading,
});

const ActionCreators = Object.assign(
  {},
  apiActions, signupActions
);
const mapDispatchToProps = dispatch => ({
  actions: bindActionCreators(ActionCreators, dispatch),
});

export default connect(
  mapStateToProps,
  mapDispatchToProps,
)(PreviewCard);
